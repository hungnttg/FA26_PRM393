//npm i express
//npm i cors
const express = require("express");
const cors = require("cors");
const app = express(); //tao doi tuong server
app.use(cors());
app.use(express.json());//dinh dang du lieu la json
//---su dung mang - bai tap: luu du lieu vao db
let products = [
    {id:1,name:"Ao thun"},
    {id:2,name:"Giay"}
];
//GET
app.get("/products",(req,res)=>{
    res.json(products);
});
//POST
app.post("/products",(req,res)=>{
    products.push({
        id:products.length+1,
        name: req.body.name //du lieu tu flutter day sang
    });
    res.json({message:"Them thanh cong"});
});
//DELETE
app.delete("/products/:id",(req,res)=>{
    products = products.filter(p=>p.id!=req.params.id);
    res.json({message:"Xoa thanh cong"});
});
//lang nghe
app.listen(3009);
