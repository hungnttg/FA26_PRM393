//npm init -y
//npm i express cors
//1. tham chieu thu vien
const express = require('express');
const cors = require('cors');
//2. tao doi tuong server
const app = express();
//3. middlerare
app.use(cors()); //cho phep flutter kets noi
app.use(express.json());//dinh dang du lieu la json
//3.endpoint
app.post("/login",(req,res)=>{
    const {email, password}=req.body;//lay du lieu tu nguoi dung nhap
    if(email == "admin@gmail.com" && password=="123"){
        res.json({
            token: "abc123"
        });
    }
    else {
        res.status(401).json({
            error: "Sai user hoac pass",
        })
    }
});
//lang nghe
app.listen(3033,()=>{
    console.log("Server running...")
});
//200: thanh cong; 401:chua login; 403: khong co quyen; 404: not found; 500: loi server