package com.example.demo.bai04;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RegistryItemRepository extends JpaRepository<RegistryItem,Long> {
}
