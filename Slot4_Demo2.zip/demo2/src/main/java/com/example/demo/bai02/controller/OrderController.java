package com.example.demo.bai02.controller;

import com.example.demo.bai02.model.Order;
import com.example.demo.bai02.repository.OrderRepository;
import com.example.demo.common.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "*")
public class OrderController {
    @Autowired
    private OrderRepository repo;
    @GetMapping
    public ResponseEntity<ApiResponse<List<Order>>> getAll(){
        List<Order> list = repo.findAll();
        return ResponseEntity.ok(ApiResponse.success(list,"Fetch all orders successfully"));
    }
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Order>> getById(@PathVariable Long id){
        Order item = repo.findById(id)
                .orElseThrow(()->new RuntimeException("Order not found with id: "+id));
        return ResponseEntity.ok(ApiResponse.success(item,"Found Order with id: "+id));
    }
    @PostMapping
    public ResponseEntity<ApiResponse<Order>> create(@RequestBody Order item){
        Order saved = repo.save(item);
        return ResponseEntity.ok(ApiResponse.success(saved,"Created Order successfully"));
    }
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Order>> update(@PathVariable Long id,@RequestBody Order updateData){
        Order existing = repo.findById(id).orElseThrow(()->new RuntimeException("Order not found with id: "+id));
        existing.setName(updateData.getName());
        existing.setPrice(updateData.getPrice());
        existing.setDescription(updateData.getDescription());
        Order saved = repo.save(existing);
        return ResponseEntity.ok(ApiResponse.success(saved,"Updated Order successfully"));
    }
    /*
    * DDD va Bounded context: xac dinh ngu canh va ranh gioi nghiep vu rieng cua Order Domain
    * package bai02 luu tru thong tin don hang, khong truy cap truc tiep vao csdl cua dv khac
    * */
}
