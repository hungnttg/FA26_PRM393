package com.example.demo.bai04;

import jakarta.persistence.*;

@Entity
@Table(name = "registry_items")
public class RegistryItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private Double price;
    private String description;

    public RegistryItem() {
    }

    public RegistryItem(Long id, String name, Double price, String description) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
/*
* CREATE TABLE registry (
	id bigint AUTO_INCREMENT PRIMARY KEY,
    name varchar(255) not null,
    price double DEFAULT 0.0,
    description varchar(500),
    created_at Timestamp DEFAULT current_timestamp
)ENGINE=INNODB DEFAULT charset=utf8mb4;
*
* INSERT INTO registry (name,price,description) values
('Sample Registry 01',150.0,'Initial data for bai 4'),
('Sample Registry 02',299.5,'Initial data for bai 4 testing');
* */