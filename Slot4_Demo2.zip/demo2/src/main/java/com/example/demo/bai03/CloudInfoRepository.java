package com.example.demo.bai03;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CloudInfoRepository extends JpaRepository<CloudInfo,Long> {
}
