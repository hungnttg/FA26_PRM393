package com.example.demo.bai04;

import com.example.demo.common.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/registry_items")
@CrossOrigin(origins = "*")
public class RegistryItemController {
    @Autowired
    private RegistryItemRepository repo;
    @GetMapping
    public ResponseEntity<ApiResponse<List<RegistryItem>>> getAll(){
        List<RegistryItem> list = repo.findAll();
        return ResponseEntity.ok(ApiResponse.success(list,"Fetch all registry_items successfully"));
    }
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<RegistryItem>> getById(@PathVariable Long id){
        RegistryItem item = repo.findById(id).orElseThrow(()->new RuntimeException("Registry not found id: "+id));
        return ResponseEntity.ok(ApiResponse.success(item,"Found registry_items id: "+id));
    }
    @PostMapping
    public ResponseEntity<ApiResponse<RegistryItem>> create(@RequestBody RegistryItem item ){
        RegistryItem saved=repo.save(item);
        return ResponseEntity.ok(ApiResponse.success(saved,"Created RegistryItem successfully"));
    }
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<RegistryItem>> update(@PathVariable Long id,@RequestBody RegistryItem updateData){
        RegistryItem exiting = repo.findById(id).orElseThrow(()->new RuntimeException("RegistryItem not found with id: "+id));
        exiting.setName(updateData.getName());
        exiting.setPrice(updateData.getPrice());
        exiting.setDescription(updateData.getDescription());
        RegistryItem saved = repo.save(exiting);
        return ResponseEntity.ok(ApiResponse.success(saved,"Updated RegistryUtem successfully"));
    }
}
