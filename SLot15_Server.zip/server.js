//npm i express mysql2 cors
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const {join} = require('node:path');
//b2 tao server
const server = express();
//b3 cau hinh server
server.use(cors());//cho phep flutter ket noi
server.use(express.json());//su dung dinh dang json
//b4. connect to mysql database
const db = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"shop"
});
//s5 - create endpoints
//get
server.get("/products",(req,res)=>{
    db.query("select * from products",(err,result)=>{
        if(err) return res.status(500).json(err);
        res.json(result);
    });
});
//post
server.post("/products",(req,res)=>{
    db.query("insert in to products (name) values (?)",[req.body.name],(err)=>{
        if(err) return res.status(500).json(err);
        res.json({message:"Added"});
    });
});
//put
server.put("/products/:id",(req,res)=>{
    db.query("update products set name=? where id=?",
        [req.body.name,req.params.id],(err)=>{
            if(err) return res.status(500).json(err);
            res.json({message:"Updated"});
        }
    );
});
//delete
server.delete("/products/:id",(req,res)=>{
    db.query("delete from products where id = ?",[req.params.id],(err)=>{
        if(err) return res.status(500).json(err);
        res.json({message:"Deleted"});
    });
});
//server listening
server.listen(3015,()=>{
    console.log("Server is running...");
});