//npm i express
//npm i mysql2
//npm i cors
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app = express();//tao doi tuong server
app.use(cors());//midleware
//thong tin CSDL
const conn = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"a14"
});
conn.connect(err=>err);//ket noi voi csdl
//tao endpoint
app.get('/data',(req,res)=>{
    conn.query('select * from mytable',(err,results)=>{
        if(err) throw err;
        res.json({products: results});//chuyen ket qua sang json
    });
});
//server lang nghe
app.listen(3011,()=>{
    console.log("Ung dung dang chay o cong 3011")
});