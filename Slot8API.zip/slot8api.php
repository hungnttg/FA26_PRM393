<?php
header('Access-Control-Allow-Origin:*');
$s="localhost"; $u="root"; $p="";$db="a14";//khai bao thong tin CSDL
$conn = new mysqli($s,$u,$p,$db);//ket noi csdl
$result = $conn->query("select * from mytable");//truy van du lieu
while($row[]=$result->fetch_assoc()){ //doc du lieu
    $json = json_encode($row);//chuyen sang json
}
echo '"products": {'.$json.'}';
?>